import { v4 as uuidv4 } from "uuid";
import userWallet from "../models/wallet.model";
import { TransactionType } from "../enums/enums";

export const getWallet = () => userWallet;

export const recharge = (amount: number) => {
  userWallet.balance += amount;
  userWallet.transactions.push({
    id: uuidv4(),
    type: TransactionType.CREDIT,
    amount,
    reason: "Recharge",
    timestamp: new Date().toISOString(),
  });
  return userWallet;
};

export const deduct = (amount: number, reason: string) => {
  if (userWallet.balance < amount) return { error: "Insufficient balance" };
  userWallet.balance -= amount;
  userWallet.transactions.push({
    id: uuidv4(),
    type: TransactionType.DEBIT,
    amount,
    reason,
    timestamp: new Date().toISOString(),
  });
  return userWallet;
};
