// src/controllers/game.controller.ts
import { Request, Response } from "express";
import * as gameService from "../services/game.service";

export const getGames = (req: Request, res: Response) => {
  res.json(gameService.getGames());
};

export const joinGame = (req: Request, res: Response) => {
  const { gameId } = req.body;
  const result = gameService.joinGame(gameId);
  if (result?.error) {
    res.status(400).json({ error: result?.error });
    return;
  }
  res.status(200).json(result);
};
