import express from "express";
import { getGames, joinGame } from "../controllers/game.controller";

const router = express.Router();

router.get("/", getGames);
//@ts-ignore
router.post("/join", joinGame);

export default router;
