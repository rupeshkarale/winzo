import { error } from "console";
import * as walletService from "./wallet.service";

const games = [
  { id: "game1", name: "Challenge & Connect", entryFee: 10, currentPlayers: 3 },
  { id: "game2", name: "Snake & Ladder", entryFee: 15, currentPlayers: 5 },
];

export const getGames = () => games;

export const joinGame = (gameId: string) => {
  const game = games.find((g) => g.id === gameId);
  if (!game) return { error: "Game not found" };
  const result = walletService.deduct(game.entryFee, `Join ${game.name}`);
  if ("error" in result) return result;
  return { message: `Joined ${game.name}`, balance: result.balance, error: "" };
};
