import express from "express";
import cors from "cors";
import walletRoutes from "./routes/wallet.routes";
import gameRoutes from "./routes/game.routes";

const app = express();
const PORT = 3001;

app.use(cors({ origin: "*" }));
app.use(express.json());
app.use((req, res, next) => {
  console.log(`[${req.method}] ${req.originalUrl}`);
  next();
});
app.use("/api/wallet", walletRoutes);
app.use("/api/games", gameRoutes);

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
