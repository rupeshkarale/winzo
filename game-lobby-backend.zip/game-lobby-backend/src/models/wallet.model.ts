import { TransactionType } from "../enums/enums";

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  reason: string;
  timestamp: string;
}

export interface Wallet {
  userId: string;
  balance: number;
  transactions: Transaction[];
}

const userWallet: Wallet = {
  userId: "user123",
  balance: 50,
  transactions: [],
};

export default userWallet;
