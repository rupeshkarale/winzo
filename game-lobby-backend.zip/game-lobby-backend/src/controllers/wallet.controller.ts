import { Request, Response } from "express";

import * as walletService from "../services/wallet.service";

export const getWallet = (req: Request, res: Response) => {
  res.json(walletService.getWallet());
};

export const rechargeWallet = (req: Request, res: Response) => {
  const { amount } = req.body;
  if (!amount || amount <= 0) {
    res.status(400).json({ error: "Invalid amount" });
    return;
  }
  const result = walletService.recharge(amount);
  res.json(result);
};
