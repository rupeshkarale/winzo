import express from "express";
import { getWallet, rechargeWallet } from "../controllers/wallet.controller";

const router = express.Router();

router.get("/", getWallet);
router.post("/recharge", rechargeWallet);

export default router;
